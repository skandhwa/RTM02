package Constants;

public class ConstantData {
	
	
	public static final String ExcelPath="src\\test\\java\\TestData\\TestData25thJune.xlsx";
    public static final String PropertyFilePath ="src\\main\\java\\Global.properties";
}

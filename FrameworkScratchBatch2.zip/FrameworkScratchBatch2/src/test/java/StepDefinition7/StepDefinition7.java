package StepDefinition7;

import org.openqa.selenium.WebDriver;

import PageFactory.RegistrationPage;
import Utilities.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition7 extends BaseClass {
	
	WebDriver driver=BaseClass.initializeDriver();
	RegistrationPage obj=new RegistrationPage(driver);
	
	
	@Given("user loads the parabanking website in the browser")
	public void user_loads_the_parabanking_website_in_the_browser() {
		
	System.out.println("The title of WebPage is  "+getTitle());	
	    
	}
	
	
	@Given("user enters the FirstName as {string}")
	public void user_enters_the_first_name_as(String FirstName) {
		
		obj.enterFirstName(FirstName);
		
		
	    
	}

	@Given("user enters the LastName as {string}")
	public void user_enters_the_last_name_as(String LastName) {
		
		
		obj.enterLastName(LastName);
		//scrollDown();
		
	    
	}

	@Given("user enters the Address as {string}")
	public void user_enters_the_address_as(String Address) {
		obj.enterStreet(Address);
	    
	}

	@Given("user enters the City as {string}")
	public void user_enters_the_city_as(String City) {
		
		obj.enterCity(City);
	    
	}

	@Given("user enters the State as {string}")
	public void user_enters_the_state_as(String State) {
		
		obj.enterState(State);
	    
	}

	@Given("user enters the ZipCode as {string}")
	public void user_enters_the_zip_code_as(String string) {
	    
	}

	@Given("user enters the Phone as {string}")
	public void user_enters_the_phone_as(String string) {
	    
	}

	@Given("user enters the SSN as {string}")
	public void user_enters_the_ssn_as(String string) {
	    
	}

	@Given("user enters the UserName as {string}")
	public void user_enters_the_user_name_as(String string) {
	    
	}

	@Given("user enters the Password as {string}")
	public void user_enters_the_password_as(String string) {
	    
	}

	@Given("user enters the confirm Password as {string}")
	public void user_enters_the_confirm_password_as(String string) {
	    
	}

	@When("user clicks on the Register button")
	public void user_clicks_on_the_register_button() {
	   
	}

	@Then("User will be navigated to Parabanking homepage")
	public void user_will_be_navigated_to_parabanking_homepage() {
	    
	}
	
	
	@Then("user closes the browser after execution")
	public void user_closes_the_browser_after_execution() throws InterruptedException {
	    
		closeDriver();
		
	}

	

}
